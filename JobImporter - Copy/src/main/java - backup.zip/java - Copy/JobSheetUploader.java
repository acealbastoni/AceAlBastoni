import utils.DBConnection;
import java.sql.*;
import java.util.*;
import java.net.*;
import java.io.*;
import com.google.gson.Gson;

public class JobSheetUploader {

    private static final String GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwvH4mqQiq1XBGn67Eh6sR-V7Bd9K5QkeqkaB1V8mTufUNbNU7uUVTS1qVfafbZkPby-g/exec";

    public static void main(String[] args) {
        List<List<String>> jobsData = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection()) {
        	String sql = "SELECT Hashed_Job_Describtion, Encrypted_Job_Description, "
        	           + "PlainText_Job_Description, "
        	           + "Attached_Emails, Profile_ID, Source, "
        	           + "Scrapped_Date, Scrapped_Version, Time_Input_The_System, SQL_generated_HMD5, dkey "
        	           + "FROM jobs "
        	           + "WHERE Scrapped_Date LIKE '202506%' "
        	           + "AND ("
        	           + "   PlainText_Job_Description LIKE '%Saudi%' "
        	           + "   OR PlainText_Job_Description LIKE '%KSA%' "
        	           + "   OR PlainText_Job_Description LIKE '%SA%' "
        	           + "   OR PlainText_Job_Description LIKE N'%السعودية%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الرياض%' "
        	           + "   OR PlainText_Job_Description LIKE N'%جدة%' "
        	           + "   OR PlainText_Job_Description LIKE N'%مكة%' "
        	           + "   OR PlainText_Job_Description LIKE N'%المدينة%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الدمام%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الخبر%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الطائف%' "
        	           + "   OR PlainText_Job_Description LIKE N'%ينبع%' "
        	           + "   OR PlainText_Job_Description LIKE N'%ابها%' "
        	           + "   OR PlainText_Job_Description LIKE N'%تبوك%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الهفوف%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الجبيل%' "
        	           + "   OR PlainText_Job_Description LIKE N'%حائل%' "
        	           + "   OR PlainText_Job_Description LIKE N'%بريدة%' "
        	           + "   OR PlainText_Job_Description LIKE N'%خميس مشيط%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الظهران%' "
        	           + "   OR PlainText_Job_Description LIKE N'%القطيف%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الجوف%' "
        	           + "   OR PlainText_Job_Description LIKE N'%نجران%' "
        	           + "   OR PlainText_Job_Description LIKE N'%الباحة%' "
        	           + "   OR PlainText_Job_Description LIKE '%N%' "
        	           + "   OR PlainText_Job_Description LIKE '% n %' "
        	           + "   OR PlainText_Job_Description LIKE '% N %' "
        	           + "   OR PlainText_Job_Description LIKE '%\\n%' "
        	           + ") "
        	           + "AND ("
        	           + "   PlainText_Job_Description LIKE '%accountant%' "
        	           + "   OR PlainText_Job_Description LIKE '%accounting%' "
        	           + "   OR PlainText_Job_Description LIKE '%finance%' "
        	           + "   OR PlainText_Job_Description LIKE '%financial%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محاسب%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محاسبة%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محاسبين%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محاسب تكاليف%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محاسب رواتب%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محاسب زكاة%' "
        	           + "   OR PlainText_Job_Description LIKE N'%مدقق%' "
        	           + "   OR PlainText_Job_Description LIKE N'%تدقيق%' "
        	           + "   OR PlainText_Job_Description LIKE N'%مالية%' "
        	           + "   OR PlainText_Job_Description LIKE N'%محلل مالي%' "
        	           + "   OR PlainText_Job_Description LIKE N'%مدير مالي%' "
        	           + "   OR PlainText_Job_Description LIKE '%senior accountant%' "
        	           + "   OR PlainText_Job_Description LIKE '%chief accountant%' "
        	           + "   OR PlainText_Job_Description LIKE '%cost accountant%' "
        	           + "   OR PlainText_Job_Description LIKE '%tax accountant%' "
        	           + "   OR PlainText_Job_Description LIKE '%payroll accountant%' "
        	           + "   OR PlainText_Job_Description LIKE '%auditor%' "
        	           + "   OR PlainText_Job_Description LIKE '%audit%' "
        	           + "   OR PlainText_Job_Description LIKE '%finance manager%' "
        	           + "   OR PlainText_Job_Description LIKE '%financial analyst%' "
        	           + ")";


            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    List<String> row = new ArrayList<>();
                    row.add(rs.getString("Hashed_Job_Describtion"));
                    row.add(rs.getString("Encrypted_Job_Description"));
                    row.add(rs.getString("PlainText_Job_Description"));
                    row.add(rs.getString("Attached_Emails"));
                    row.add(rs.getString("Profile_ID"));
                    row.add(rs.getString("Source"));
                    row.add(rs.getString("Scrapped_Date"));
                    row.add(rs.getString("Scrapped_Version"));
                    row.add(rs.getString("Time_Input_The_System"));
                    row.add(rs.getString("SQL_generated_HMD5"));
                    row.add(rs.getString("dkey"));
                    jobsData.add(row);
                }
            }

            if (jobsData.isEmpty()) {
                System.out.println("⚠️ No data found for scrapped_date = 2025-07-12");
                return;
            }

            System.out.println("✅ Rows to upload: " + jobsData.size());
            boolean success = sendDataToGoogleSheet(jobsData);
            if (success) {
                System.out.println("✅ Data successfully uploaded to Google Sheet.");
            } else {
                System.out.println("❌ Failed to upload data to Google Sheet.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean sendDataToGoogleSheet(List<List<String>> data) {
        try {
            URL url = new URL(GOOGLE_SCRIPT_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            Map<String, Object> requestData = new HashMap<>();
            requestData.put("data", data);

            String json = new Gson().toJson(requestData);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = json.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = conn.getResponseCode();
            System.out.println("🌐 HTTP Response Code: " + code);

            if (code == 200) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    System.out.println("📨 Response: " + response.toString());
                }
                return true;
            } else {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    System.err.println("❌ Error Response: " + response.toString());
                }
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
