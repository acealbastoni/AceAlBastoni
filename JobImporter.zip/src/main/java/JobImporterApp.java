import model.Job;
import utils.DBConnection;

import java.io.File;
import java.nio.file.*;
import java.security.MessageDigest;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JobImporterApp {
    private static final String FOLDER_PATH = "C:/rclone/rclone-v1.66.0-windows-amd64/New folder/New folder (6)";
    private static final String SEPARATOR = "████████████████████████████████████████████████████████████████████████████████████████████████████";

    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            Files.list(Paths.get(FOLDER_PATH))
                 .filter(path -> path.toString().endsWith(".txt"))
                 .forEach(path -> processFile(path.toFile(), conn));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void processFile(File file, Connection conn) {
        try {
            String[] parts = file.getName().split("█");
            String profileId = parts[2];
            String scrappedDate = parts[3];
            String source = parts[4];
            String scrappedVersion = parts[5].replace(".txt", "");

            String content = new String(Files.readAllBytes(file.toPath()), "UTF-8");
            String[] jobs = content.split(SEPARATOR);

            for (String jobText : jobs) {
                String plainText = jobText.trim();
                if (plainText.isEmpty()) continue;

                Job job = new Job();
                job.setPlainText(plainText);
                job.setProfileId(profileId);
                job.setScrappedDate(scrappedDate);
                job.setSource(source);
                job.setScrappedVersion(scrappedVersion);
                job.setTimeInputTheSystem(currentTimestamp());
                job.setHashedDescription(md5(plainText));
                job.setSqlGeneratedMD5(md5(plainText));
                job.setEncryptedDescription(null);
                job.setAttachedEmails(null);

                insertJob(job, conn);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String currentTimestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    private static String md5(String input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hash = md.digest(input.getBytes("UTF-8"));
        StringBuilder hex = new StringBuilder();
        for (byte b : hash) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    private static void insertJob(Job job, Connection conn) throws SQLException {
        String sql = "INSERT INTO jobs (PlainText_Job_Description, Hashed_Job_Description, Encrypted_Job_Description, " +
                     "Attached_Emails, Profile_ID, Source, Scrapped_Date, Scrapped_Version, Time_Input_The_System, SQL_generated_HMD5) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, job.getPlainText());
            stmt.setString(2, job.getHashedDescription());
            stmt.setString(3, job.getEncryptedDescription());
            stmt.setString(4, job.getAttachedEmails());
            stmt.setString(5, job.getProfileId());
            stmt.setString(6, job.getSource());
            stmt.setString(7, job.getScrappedDate());
            stmt.setString(8, job.getScrappedVersion());
            stmt.setString(9, job.getTimeInputTheSystem());
            stmt.setString(10, job.getSqlGeneratedMD5());
            stmt.executeUpdate();
        }
    }
}
